/*
Name:Amirreza Moghadam
Course: WEBD6201
*/
"use strict";
(function () {
    const users = [
        {
          DisplayName: "John Smith",
          EmailAddress: "john.smith@example.com",
          Username: "johnsmith",
          Password: "123456"
        },
        {
          DisplayName: "May Smith",
          EmailAddress: "may.smith@example.com",
          Username: "maysmith",
          Password: "123456"
        },
        {
          DisplayName: "Admin",
          EmailAddress: "admin@example.com",
          Username: "admin",
          Password: "123456"
        }
      ];
       
    function LoadLink(link, data = "") {
        router.ActiveLink = link;
        router.LinkData = data;
        history.pushState({}, "", router.ActiveLink);
        document.title = router.ActiveLink.substring(0, 1).toUpperCase() + router.ActiveLink.substring(1);
        $("ul>li>a").each(function () {
            $(this).removeClass("active");
        });
        $(`li>a:contains(${document.title})`).addClass("active");
        CheckLogin();
        LoadContent();
    }
    function AddNavigationEvents() {
        let NavLinks = $("ul>li>a");
        NavLinks.off("click");
        NavLinks.off("mouseover");
        NavLinks.on("click", function () {
            LoadLink($(this).attr("data"));
        });
        NavLinks.on("mouseover", function () {
            $(this).css("cursor", "pointer");
        });
    }
    function AddLinkEvents(link) {
        let linkQuery = $(`a.link[data=${link}]`);
        linkQuery.off("click");
        linkQuery.off("mouseover");
        linkQuery.off("mouseout");
        linkQuery.css("text-decoration", "underline");
        linkQuery.css("color", "blue");
        linkQuery.on("click", function () {
            LoadLink(`${link}`);
        });
        linkQuery.on("mouseover", function () {
            $(this).css('cursor', 'pointer');
            $(this).css('font-weight', 'bold');
        });
        linkQuery.on("mouseout", function () {
            $(this).css('font-weight', 'normal');
        });
    }
    function LoadHeader() {
        $.get("../Views/components/header.html", function (html_data) {
            $("header").html(html_data);
            AddNavigationEvents();
            CheckLogin();
        });
    }
    function LoadContent() {
        let page_name = router.ActiveLink;
        let callback = ActiveLinkCallBack();
        $.get(`./Views/content/${page_name}.html`, function (html_date) {
            $("main").html(html_date);
            callback();
        });
    }
    function LoadFooter() {
        $.get(`./Views/components/footer.html`, function (html_date) {
            $("footer").html(html_date);
        });
    }
    function DisplayHomePage() {
        console.log("Home Page");
        $("#AboutUsButton").on("click", () => {
            LoadLink("about");
        });
        $("main").append(`<p id="MainParagraph" class="mt-3">This is the Main Paragraph</p>`);
        $("main").append(`<article>
        <p id="ArticleParagraph" class ="mt-3">This is the Article Paragraph</p>
        </article>`);
    }
    function DisplayProductsPage() {
        console.log("Products Page");
    }
    function DisplayServicesPage() {
        console.log("Services Page");
    }
    function DisplayAboutPage() {
        console.log("About Page");
    }
    function AddContact(fullName, contactNumber, emailAddress) {
        let contact = new core.Contact(fullName, contactNumber, emailAddress);
        if (contact.serialize()) {
            let key = contact.FullName.substring(0, 1) + Date.now();
            localStorage.setItem(key, contact.serialize());
        }
    }
    function ValidateField(fieldID, regular_expression, error_message) {
        let messageArea = $("#messageArea").hide();
        $("#" + fieldID).on("blur", function () {
            let text_value = $(this).val();
            if (!regular_expression.test(text_value)) {
                $(this).trigger("focus").trigger("select");
                messageArea.addClass("alert alert-danger").text(error_message).show();
            }
            else {
                messageArea.removeAttr("class").hide();
            }
        });
    }
    function ContactFormValidation() {
        ValidateField("fullName", /^([A-Z][a-z]{1,3}.?\s)?([A-Z][a-z]{1,})((\s|,|-)([A-Z][a-z]{1,}))*(\s|,|-)([A-Z][a-z]{1,})$/, "Please enter a valid Full Name. This must include at least a Capitalized First Name and a Capitalized Last Name.");
        ValidateField("contactNumber", /^(\+\d{1,3}\s)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}$/, "Please enter a valid Contact Number. Example: (416) 555-5555");
        ValidateField("emailAddress", /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,10}$/, "Please enter a valid Email Address.");
    }
    function DisplayContactPage() {
        console.log("Contact Page");
        $("a[data='contact-list']").off("click");
        $("a[data='contact-list']").on("click", function () {
            LoadLink("contact-list");
        });
        ContactFormValidation();
        let sendButton = document.getElementById("sendButton");
        let subscribeCheckbox = document.getElementById("subscribeCheckbox");
        sendButton.addEventListener("click", function (event) {
            if (subscribeCheckbox.checked) {
                let fullName = document.forms[0].fullName.value;
                let contactNumber = document.forms[0].contactNumber.value;
                let emailAddress = document.forms[0].emailAddress.value;
                let contact = new core.Contact(fullName, contactNumber, emailAddress);
                if (contact.serialize()) {
                    let key = contact.FullName.substring(0, 1) + Date.now();
                    localStorage.setItem(key, contact.serialize());
                }
            }
        });
    }
    function DisplayContactListPage() {
        if (localStorage.length > 0) {
            let contactList = document.getElementById("contactList");
            let data = "";
            let keys = Object.keys(localStorage);
            let index = 1;
            for (const key of keys) {
                let contactData = localStorage.getItem(key);
                let contact = new core.Contact();
                contact.deserialize(contactData);
                data += `<tr>
                <th scope="row" class="text-center">${index}</th>
                <td>${contact.FullName}</td>
                <td>${contact.ContactNumber}</td>
                <td>${contact.EmailAddress}</td>
                <td class="text-center"><button value="${key}" class="btn btn-primary btn-sm edit"><i class="fas fa-edit fa-sm"></i> Edit</button></td>
                <td class="text-center"><button value="${key}" class="btn btn-danger btn-sm delete"><i class="fas fa-trash-alt fa-sm"></i> Delete</button></td>
                </tr>`;
                index++;
            }
            contactList.innerHTML = data;
            $("button.delete").on("click", function () {
                if (confirm("Are you sure?")) {
                    localStorage.removeItem($(this).val());
                }
                LoadLink("contact-list");
            });
            $("button.edit").on("click", function () {
                LoadLink("edit", $(this).val());
            });
        }
        $("#addButton").on("click", () => {
            LoadLink("edit", "add");
        });
    }
    function DisplayEditPage() {
        console.log("Edit Page");
        ContactFormValidation();
        let page = router.LinkData;
        switch (page) {
            case "add":
                {
                    $("main>h1").text("Add Contact");
                    $("#editButton").html(`<i class="fas fa-plus-circle fa-lg"></i> Add`);
                    $("#editButton").on("click", (event) => {
                        event.preventDefault();
                        let fullName = document.forms[0].fullName.value;
                        let contactNumber = document.forms[0].contactNumber.value;
                        let emailAddress = document.forms[0].emailAddress.value;
                        AddContact(fullName, contactNumber, emailAddress);
                        LoadLink("contact-list");
                    });
                    $("#cancelButton").on("click", () => {
                        LoadLink("contact-list");
                    });
                }
                break;
            default:
                {
                    let contact = new core.Contact();
                    contact.deserialize(localStorage.getItem(page));
                    $("#fullName").val(contact.FullName);
                    $("#contactNumber").val(contact.ContactNumber);
                    $("#emailAddress").val(contact.EmailAddress);
                    $("#editButton").on("click", (event) => {
                        event.preventDefault();
                        contact.FullName = $("#fullName").val();
                        contact.ContactNumber = $("#contactNumber").val();
                        contact.EmailAddress = $("#emailAddress").val();
                        localStorage.setItem(page, contact.serialize());
                        LoadLink("contact-list");
                    });
                    $("#cancelButton").on("click", () => {
                        LoadLink("contact-list");
                    });
                }
                break;
        }
    }
    function CheckLogin() {
        if (sessionStorage.getItem("user")) {

            $("#login").html(`<a id="logout" class="nav-link" href="#"><i class="fas fa-sign-out-alt"></i> Logout</a>`);
            let userT = new core.User(); 
            userT.deserialize(sessionStorage.getItem("user"));
            let displayName = userT.DisplayName;
            $("#user-name").html(`<a id="user-name" class="nav-link" href="#"><i ></i> Hi, ${displayName}</a>`);
            $("#logout").on("click", function () {
                sessionStorage.clear();

                $("#login").html(`<a class="nav-link" data="login"><i class="fas fa-sign-in-alt"></i> Login</a>`);
                $("#user-name").html(`<a id="user-name" class="nav-link" href="#"><i ></i></a>`);

                AddNavigationEvents();
                LoadLink("login");
            });
        }
        else {
            $("#contact-list").hide();
            $("#task-list").hide();
        }
    }
    function DisplayLoginPage() {
        console.log("Login Page");
      
        let messageArea = $("#messageArea");
        messageArea.hide();
      
        AddLinkEvents("register");
      
        $("#loginButton").on("click", function() {
          let success = false;
          let newUser = new core.User();
      
          for (const user of users) {
            let username = document.forms[0].username.value;
            let password = document.forms[0].password.value;
      
            if (username == user.Username && password == user.Password) {
              newUser.DisplayName = user.DisplayName;
              newUser.EmailAddress = user.EmailAddress;
              newUser.Username = user.Username;
              newUser.Password = user.Password;
      
              success = true;
              break;
            }
          }
      
          if (success) {
            sessionStorage.setItem("user", newUser.serialize());
            messageArea.removeAttr("class").hide();
            LoadLink("contact");
          } else {
            $("#username").trigger("focus").trigger("select");
            messageArea.addClass("alert alert-danger").text("Error: Invalid Login Information").show();
          }
        });
      
        $("#cancelButton").on("click", function() {
          document.forms[0].reset();
          LoadLink("home");
        });
      }
    function RegisterFromValidation(){
        const namePattern = /^[A-Za-z]{2,}$/;
        const emailPattern=/^.{8,}@.*$/;
        const passPattern=/^\S{6,}$/;
        ValidateField("FirstName", namePattern, "Please enter a valid First Name (Enter at least 2 chars).");
        ValidateField("lastName", namePattern, "Please enter a valid Last Name (Enter at least 2 chars).");
        ValidateField("emailAddress", emailPattern, "Please enter a valid Email Address. (Emails (users) has to be at least 8 chars).");
        ValidateField("password",passPattern, "Invalid password, password has to be at least 6 chars.");
        ValidateField("confirmPassword",passPattern,"Invalid password, password has to be at least 6 chars.");

        let messageArea = $("#messageArea").hide();
        $("#" + 'confirmPassword').on("blur", function () {
            let password = $('#password').val();
            let confirmPassword = $('#confirmPassword').val();
            
            if (password !== confirmPassword) {
                $(this).trigger("focus").trigger("select");
                messageArea.addClass("alert alert-danger").text("The confirm password does not match password you entered.").show();
            }
            else {
                messageArea.removeAttr("class").hide();
            }
        });

    }
    function AddUser(firstname, lastname, emailaddress, password)
    {
        let newUser = new core.User(firstname+" "+lastname,emailaddress, firstname+lastname, password);
        if(newUser.serialize())
        {
            console.log(newUser.toString());
        }
    }        
    function DisplayRegisterPage() {
        console.log("Register Page");
        AddLinkEvents("login");
      
        let messageArea = $("#messageArea");
        messageArea.hide();
      
        RegisterFromValidation();
        $("#submitButton").on("click", (event) => {
            event.preventDefault();
            let firstname = document.forms[0].firstName.value;
            let lastname = document.forms[0].lastName.value;
            let emailAddress = document.forms[0].emailAddress.value;
            let pass = document.forms[0].password.value;
            AddUser(firstname, lastname, emailAddress, password);
        });


    }
    function Display404Page() {
    }
    function AddNewTask() {
        let messageArea = $("#messageArea");
        messageArea.hide();
        let taskInput = $("#taskTextInput");
        let taskInputValue = taskInput.val();
        if (taskInput.val() != "" && taskInputValue.charAt(0) != " ") {
            let newElement = `
               <li class="list-group-item" id="task">
               <span id="taskText">${taskInput.val()}</span>
               <span class="float-end">
                   <button class="btn btn-outline-primary btn-sm editButton"><i class="fas fa-edit"></i>
                   <button class="btn btn-outline-danger btn-sm deleteButton"><i class="fas fa-trash-alt"></i></button>
               </span>
               <input type="text" class="form-control edit-task editTextInput">
               </li>
               `;
            $("#taskList").append(newElement);
            messageArea.removeAttr("class").hide();
            taskInput.val("");
        }
        else {
            taskInput.trigger("focus").trigger("select");
            messageArea.show().addClass("alert alert-danger").text("Please enter a valid Task.");
        }
    }
    function DisplayTaskList() {
        AuthGuard();
        let messageArea = $("#messageArea");
        messageArea.hide();
        let taskInput = $("#taskTextInput");
        $("#newTaskButton").on("click", function () {
            AddNewTask();
        });
        taskInput.on("keypress", function (event) {
            if (event.key == "Enter") {
                AddNewTask();
            }
        });
        $("ul").on("click", ".editButton", function () {
            let editText = $(this).parent().parent().children(".editTextInput");
            let text = $(this).parent().parent().text();
            let editTextValue = editText.val();
            editText.val(text).show().trigger("select");
            editText.on("keypress", function (event) {
                if (event.key == "Enter") {
                    if (editText.val() != "" && editTextValue.charAt(0) != " ") {
                        editText.hide();
                        $(this).parent().children("#taskText").text(editTextValue);
                        messageArea.removeAttr("class").hide();
                    }
                    else {
                        editText.trigger("focus").trigger("select");
                        messageArea.show().addClass("alert alert-danger").text("Please enter a valid Task.");
                    }
                }
            });
        });
        $("ul").on("click", ".deleteButton", function () {
            if (confirm("Are you sure?")) {
                $(this).closest("li").remove();
            }
        });
    }
    function ActiveLinkCallBack() {
        switch (router.ActiveLink) {
            case "home": return DisplayHomePage;
            case "about": return DisplayAboutPage;
            case "products": return DisplayProductsPage;
            case "services": return DisplayServicesPage;
            case "contact": return DisplayContactPage;
            case "contact-list": return DisplayContactListPage;
            case "edit": return DisplayEditPage;
            case "login": return DisplayLoginPage;
            case "register": return DisplayRegisterPage;
            case "task-list": return DisplayTaskList;
            case "404": return Display404Page;
            default:
                console.error("ERROR: callback does not exist: " + router.ActiveLink);
                return new Function();
        }
    }
    function Start() {
        console.log("App Started!");
        LoadHeader();
        LoadLink("home");
        LoadFooter();
    }
    window.addEventListener("load", Start);
})();
//# sourceMappingURL=app.js.map